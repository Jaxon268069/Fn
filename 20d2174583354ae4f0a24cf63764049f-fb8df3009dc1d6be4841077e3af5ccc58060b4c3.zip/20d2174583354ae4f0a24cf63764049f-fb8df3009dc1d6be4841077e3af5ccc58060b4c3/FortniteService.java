package com.tb24.fn.network;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.tb24.fn.model.AccountPrivacyResponse;
import com.tb24.fn.model.InventorySnapshotResponse;
import com.tb24.fn.model.MatchmakingTicketResponse;
import com.tb24.fn.model.cloudstorage.CloudStorageFile;
import com.tb24.fn.model.cloudstorage.CloudStorageUsageInfo;
import com.tb24.fn.model.gamesubcatalog.CatalogDownload;
import com.tb24.fn.model.gamesubcatalog.CatalogReceiptInfo;
import com.tb24.fn.model.links.LinkEntry;
import com.tb24.fn.model.links.LinksQueryResponse;
import com.tb24.fn.model.mcpprofile.ProfileUpdate;
import com.tb24.fn.model.scheduledevents.CalendarDownload;
import okhttp3.RequestBody;
import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.http.*;

import java.util.Map;

public interface FortniteService {
	String BASE_URL = "https://fortnite-public-service-prod11.ol.epicgames.com/fortnite/";

	@POST("api/game/v2/profile/{id}/client/{command}")
	Call<ProfileUpdate> clientCommand(@Path("command") String command, @Path("id") String accountId, @Query("profileId") String profileId, @Query("rvn") Long currentProfileRevision, @Header("X-EpicGames-ProfileRevisions") String profileRevisionsMeta, @Body Object payload);

	@POST("api/game/v2/profile/{id}/public/{command}")
	Call<ProfileUpdate> publicCommand(@Path("command") String command, @Path("id") String accountId, @Query("profileId") String profileId, @Query("rvn") Long currentProfileRevision, @Header("X-EpicGames-ProfileRevisions") String profileRevisionsMeta, @Body Object payload);

	@GET("api/game/v2/world/info")
	Call<ResponseBody> queryTheaterList(@Header("X-EpicGames-Language") String language);

	@GET("api/game/v2/privacy/account/{id}")
	Call<AccountPrivacyResponse> getAccountPrivacy(@Path("id") String id);

	@POST("api/game/v2/privacy/account/{id}")
	Call<AccountPrivacyResponse> setAccountPrivacy(@Path("id") String id, @Body AccountPrivacyResponse payload);

	@GET("api/storefront/v2/catalog")
	Call<CatalogDownload> storefrontCatalog(@Header("X-EpicGames-Language") String language);

	@GET("api/calendar/v1/timeline")
	Call<CalendarDownload> calendarTimeline();

	@GET("api/cloudstorage/system")
	Call<CloudStorageFile[]> enumerateTitleFiles();

	@GET("api/cloudstorage/system/{filename}")
	Call<ResponseBody> readTitleFile(@Path("filename") String filename);

	@GET("api/cloudstorage/user/{id}")
	Call<CloudStorageFile[]> enumerateUserFiles(@Path("id") String id);

	@GET("api/cloudstorage/user/{id}/{filename}")
	Call<ResponseBody> readUserFile(@Path("id") String id, @Path("filename") String filename);

	@PUT("api/cloudstorage/user/{id}/{filename}")
	Call<Void> writeUserFile(@Path("id") String id, @Path("filename") String filename, @Body RequestBody newFile);

	@DELETE("api/cloudstorage/user/{id}/{filename}")
	Call<Void> deleteUserFile(@Path("id") String id, @Path("filename") String filename);

	@GET("api/cloudstorage/storage/{id}/info")
	Call<CloudStorageUsageInfo> requestUsageInfo(@Path("id") String accountId);

	@POST("api/game/v2/events/v2/processPendingRewards/{id}")
	Call<String[]> processPendingRewards(@Path("id") String id);

	/**
	 * platform PC, MOBILE, PS4, XBOX_ONE, or SWITCH
	 */
	@POST("api/game/v2/tryPlayOnPlatform/account/{id}")
	Call<Boolean> checkPlatformPlayAllowed(@Path("id") String id, @Query("platform") String platform);

	@GET("api/game/v2/enabled_features")
	Call<JsonElement[]> enabledFeatures();

	@POST("api/game/v2/grant_access/{id}")
	Call<Void> grantAccess(@Path("id") String id);

	@GET("api/storefront/v2/keychain")
	Call<String[]> storefrontKeychain(@Query("numKeysDownloaded") Integer numKeysDownloaded);

	@GET("api/receipts/v1/account/{id}/receipts")
	Call<CatalogReceiptInfo[]> receipts(@Path("id") String id);

	//@POST("api/storeaccess/v1/redeem_access/{id}")
	//Call<Void> redeemAccess(@Path("id") String id); // requires payload, unknown

	@POST("api/storeaccess/v1/request_access/{id}")
	Call<Void> requestAccess(@Path("id") String id);

	@POST("api/accesscontrol/status")
	Call<JsonObject> checkAccess(); // { play: boolean, isBanned: boolean }

	/**
	 * @param olderThan in ISO 8601 date format
	 */
	@GET("api/game/v2/creative/favorites/{accountId}")
	Call<LinksQueryResponse> queryCreativeFavorites(@Path("accountId") String accountId, @Query("limit") Integer limit, @Query("olderThan") String olderThan);

	@PUT("api/game/v2/creative/favorites/{accountId}/{mnemonic}")
	Call<LinkEntry> addCodeToCreativeFavorites(@Path("accountId") String accountId, @Path("mnemonic") String mnemonic);

	@DELETE("api/game/v2/creative/favorites/{accountId}/{mnemonic}")
	Call<Void> removeCodeFromCreativeFavorites(@Path("accountId") String accountId, @Path("mnemonic") String mnemonic);

	/**
	 * @param olderThan in ISO 8601 date format
	 */
	@GET("api/game/v2/creative/history/{accountId}")
	Call<LinksQueryResponse> queryCreativeHistory(@Path("accountId") String accountId, @Query("limit") Integer limit, @Query("olderThan") String olderThan);

	/**
	 * Requires permission fortnite:fortnite_role:dedicated_server ALL
	 */
	@PUT("api/game/v2/creative/history/{accountId}/{mnemonic}")
	Call<LinkEntry> addCodeToCreativeHistory(@Path("accountId") String accountId, @Path("mnemonic") String mnemonic);

	@DELETE("api/game/v2/creative/history/{accountId}/{mnemonic}")
	Call<Void> removeCodeFromCreativeHistory(@Path("accountId") String accountId, @Path("mnemonic") String mnemonic);

	@GET("api/storefront/v2/gift/check_eligibility/recipient/{recipientAccountId}/offer/{offerId}")
	Call<Void> checkGiftEligibility(@Path("recipientAccountId") String recipientAccountId, @Path("offerId") String offerId);

	@GET("api/game/v2/br-inventory/account/{accountId}")
	Call<InventorySnapshotResponse> inventorySnapshot(@Path("accountId") String accountId);

	@GET("api/game/v2/matchmakingservice/ticket/player/{accountId}")
	Call<MatchmakingTicketResponse> mmsObtainTicket(@Path("accountId") String accountId, @QueryMap Map<String, String> params);
}
