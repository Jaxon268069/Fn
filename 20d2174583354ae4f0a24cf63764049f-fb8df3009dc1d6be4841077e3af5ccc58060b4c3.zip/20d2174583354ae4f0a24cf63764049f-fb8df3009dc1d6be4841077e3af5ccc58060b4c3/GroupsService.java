package com.tb24.fn.network;

import com.google.gson.JsonElement;
import com.tb24.fn.model.CreateGroupRequest;
import com.tb24.fn.model.Group;
import com.tb24.fn.model.GroupApplication;
import com.tb24.fn.model.GroupBlacklistEntry;
import com.tb24.fn.model.GroupInvitation;
import com.tb24.fn.model.GroupMember;
import com.tb24.fn.model.GroupMembership;
import com.tb24.fn.model.GroupSimpleInfo;
import com.tb24.fn.model.GroupUpdatePayload;
import com.tb24.fn.model.Paged;

import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.DELETE;
import retrofit2.http.GET;
import retrofit2.http.Headers;
import retrofit2.http.POST;
import retrofit2.http.PUT;
import retrofit2.http.Path;
import retrofit2.http.Query;

/**
 * Page count of paginated responses here is 50.
 */
public interface GroupsService {
	String BASE_URL_PROD = "https://groups-service-prod06.ol.epicgames.com/groups/";
	String BASE_URL_PROD_ALT = "https://groups-service-prod.ak.epicgames.com/groups/";
	String BASE_URL_PROD_STAGE = "https://groups-service-stage.ol.epicgames.com/groups/";

	@GET("api/v1/groups/in/{ns}")
	Call<Paged<Group>> FindGroups(@Path("ns") String ns, @Query("q") String query, @Query("page") Integer page);

	@POST("api/v1/groups/in/{ns}")
	Call<Group> CreateGroup(@Path("ns") String ns, @Body CreateGroupRequest payload);

	/**
	 * {@link GroupMembership} contains {@link GroupSimpleInfo}.
	 */
	@GET("api/v1/user/in/{ns}/{accountId}/membership")
	Call<Paged<GroupMembership>> QueryUserMembership(@Path("ns") String ns, @Path("accountId") String accountId, @Query("page") Integer page);

	/**
	 * {@link GroupApplication} contains {@link GroupSimpleInfo}.
	 */
	@GET("api/v1/user/in/{ns}/{accountId}/applications/outgoing")
	Call<Paged<GroupApplication>> QueryOutgoingApplications(@Path("ns") String ns, @Path("accountId") String accountId, @Query("page") Integer page);

	/**
	 * {@link GroupApplication} contains {@link GroupSimpleInfo}.
	 */
	@GET("api/v1/user/in/{ns}/{accountId}/applications/incoming")
	Call<Paged<GroupApplication>> QueryIncomingApplications(@Path("ns") String ns, @Path("accountId") String accountId, @Query("page") Integer page);

	/**
	 * {@link GroupInvitation} contains {@link GroupSimpleInfo}.
	 */
	@GET("api/v1/user/in/{ns}/{accountId}/invitations/outgoing")
	Call<Paged<GroupInvitation>> QueryOutgoingInvitations(@Path("ns") String ns, @Path("accountId") String accountId, @Query("page") Integer page);

	/**
	 * {@link GroupInvitation} contains {@link GroupSimpleInfo}.
	 */
	@GET("api/v1/user/in/{ns}/{accountId}/invitations/incoming")
	Call<Paged<GroupInvitation>> QueryIncomingInvitations(@Path("ns") String ns, @Path("accountId") String accountId, @Query("page") Integer page);

	@GET("api/v1/groups/{groupId}")
	Call<Group> QueryGroupInfo(@Path("groupId") String groupId);

	@POST("api/v1/groups/{groupId}")
	Call<Group> UpdateGroupInfo(@Path("groupId") String groupId, @Body GroupUpdatePayload payload);

	@DELETE("api/v1/groups/{groupId}")
	Call<Void> DeleteGroup(@Path("groupId") String groupId);

	@PUT("api/v1/groups/{groupId}/owner/{accountId}")
	Call<Void> TransferGroup(@Path("groupId") String groupId, @Path("accountId") String accountId);

	@GET("api/v1/groups/{groupId}/members")
	Call<Paged<GroupMember>> QueryGroupRoster(@Path("groupId") String groupId, @Query("page") Integer page);

	@GET("api/v1/groups/{groupId}/members/{accountId}")
	Call<GroupMember> QueryGroupMember(@Path("groupId") String groupId, @Path("accountId") String accountId);

	// 404, errors.com.epicgames.social.groups.not_found.group, Group has not been found: group (id=a168ccedec5b4c4f834f10677005ffdd) does not exists or is not of proper type (type=KAIROS)
	// Maybe for joining the group if the group is open (doesn't require approval)
	@POST("api/v1/groups/{groupId}/members/{accountId}")
	@Headers("Content-Type: application/json")
	Call<JsonElement> UNKNOWN(@Path("groupId") String groupId, @Path("accountId") String accountId);

	/**
	 * Can also be used to leave the group.
	 */
	@DELETE("api/v1/groups/{groupId}/members/{accountId}")
	Call<Void> RemoveUser(@Path("groupId") String groupId, @Path("accountId") String accountId);

	@GET("api/v1/groups/{groupId}/admins")
	Call<Paged<String>> QueryGroupAdmins(@Path("groupId") String groupId, @Query("page") Integer page);

	@PUT("api/v1/groups/{groupId}/admins/{accountId}")
	Call<Void> PromoteUser(@Path("groupId") String groupId, @Path("accountId") String accountId);

	@DELETE("api/v1/groups/{groupId}/admins/{accountId}")
	Call<Void> DemoteUser(@Path("groupId") String groupId, @Path("accountId") String accountId);

	@GET("api/v1/groups/in/{ns}/{name}")
	Call<Group> QueryGroupByName(@Path("ns") String ns, @Path("name") String name);

	@GET("api/v1/groups/in/{ns}/{name}/exist")
	Call<Boolean> QueryGroupNameExist(@Path("ns") String ns, @Path("name") String name);

	@GET("api/v1/groups/{groupId}/invitations")
	Call<Paged<GroupInvitation>> QueryGroupInvites(@Path("groupId") String groupId, @Query("page") Integer page);

	@GET("api/v1/groups/{groupId}/invitations/{accountId}")
	Call<GroupInvitation> QueryGroupInvite(@Path("groupId") String groupId, @Path("accountId") String accountId);

	@POST("api/v1/groups/{groupId}/invitations/{accountId}")
	@Headers("Content-Type: application/json")
	Call<GroupInvitation> InviteUser(@Path("groupId") String groupId, @Path("accountId") String accountId);

	@DELETE("api/v1/groups/{groupId}/invitations/{accountId}")
	Call<Void> CancelInvite(@Path("groupId") String groupId, @Path("accountId") String accountId);

	@POST("api/v1/groups/{groupId}/invitations/{accountId}/accept")
	@Headers("Content-Type: application/json")
	Call<GroupMember> AcceptInvite(@Path("groupId") String groupId, @Path("accountId") String accountId);

	@POST("api/v1/groups/{groupId}/invitations/{accountId}/reject")
	@Headers("Content-Type: application/json")
	Call<GroupInvitation> DeclineInvite(@Path("groupId") String groupId, @Path("accountId") String accountId);

	@GET("api/v1/groups/{groupId}/applications")
	Call<Paged<GroupApplication>> QueryGroupRequests(@Path("groupId") String groupId, @Query("page") Integer page);

	@GET("api/v1/groups/{groupId}/applications/{accountId}")
	Call<GroupApplication> QueryGroupRequest(@Path("groupId") String groupId, @Path("accountId") String accountId);

	@POST("api/v1/groups/{groupId}/applications/{accountId}")
	@Headers("Content-Type: application/json")
	Call<GroupApplication> JoinGroup(@Path("groupId") String groupId, @Path("accountId") String accountId);

	@DELETE("api/v1/groups/{groupId}/applications/{accountId}")
	Call<Void> CancelGroupRequest(@Path("groupId") String groupId, @Path("accountId") String accountId);

	@POST("api/v1/groups/{groupId}/applications/{accountId}/accept")
	@Headers("Content-Type: application/json")
	Call<GroupMember> AcceptUser(@Path("groupId") String groupId, @Path("accountId") String accountId);

	@POST("api/v1/groups/{groupId}/applications/{accountId}/reject")
	@Headers("Content-Type: application/json")
	Call<GroupApplication> DeclineUser(@Path("groupId") String groupId, @Path("accountId") String accountId);

	@GET("api/v1/groups/{groupId}/blacklist")
	Call<Paged<GroupBlacklistEntry>> QueryGroupBlacklist(@Path("groupId") String groupId, @Query("page") Integer page);

	@PUT("api/v1/groups/{groupId}/blacklist/{accountId}")
	Call<GroupBlacklistEntry> BlockUser(@Path("groupId") String groupId, @Path("accountId") String accountId);

	@DELETE("api/v1/groups/{groupId}/blacklist/{accountId}")
	Call<Void> UnblockUser(@Path("groupId") String groupId, @Path("accountId") String accountId);

	@GET("api/v1/config/{ns}/limits/headcount")
	Call<Integer> QueryConfigHeadcount(@Path("ns") String ns);

	@GET("api/v1/config/{ns}/limits/membership")
	Call<Integer> QueryConfigMembership(@Path("ns") String ns);
}
