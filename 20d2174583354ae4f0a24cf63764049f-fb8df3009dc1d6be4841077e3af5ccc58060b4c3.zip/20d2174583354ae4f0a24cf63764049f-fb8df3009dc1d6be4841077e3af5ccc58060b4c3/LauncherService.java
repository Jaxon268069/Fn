package com.tb24.fn.network;

import com.tb24.fn.model.launcher.BuildResponse;
import com.tb24.fn.model.launcher.ClientDetails;
import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.POST;
import retrofit2.http.Path;

public interface LauncherService {
	String BASE_URL_PROD = "https://launcher-public-service-prod06.ol.epicgames.com/launcher/";
	String BASE_URL_STAGE = "https://launcher-public-service-stage.ol.epicgames.com/launcher/";

	@POST("api/public/assets/v2/platform/{platform}/catalogItem/{catalogItemId}/app/{appName}/label/{label}")
	Call<BuildResponse> querySignedDownload(@Path("platform") String platform, @Path("catalogItemId") String catalogItemId, @Path("appName") String appName, @Path("label") String label, @Body ClientDetails clientDetails);
}
