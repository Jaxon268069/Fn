package com.tb24.fn.network;

import com.tb24.fn.model.links.LinkData;
import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Path;
import retrofit2.http.Query;

public interface LinksService {
	String BASE_URL_LIVE = "https://links-public-service-live.ol.epicgames.com/links/";
	String BASE_URL_PROD = "https://links-public-service-prod.ol.epicgames.com/links/";
	String BASE_URL_STAGE = "https://links-public-service-stage.ol.epicgames.com/links/";

	@GET("api/{namespace}/mnemonic/{mnemonic}")
	Call<LinkData> queryLinkByMnemonic(@Path("namespace") String namespace, @Path("mnemonic") String mnemonic, @Query("type") String type, @Query("v") Integer version);

	/*@GET("api/{namespace}/author/{accountId}")
	Call<ResponseBody> queryLinksByAccount(@Path("namespace") String namespace, @Path("accountId") String accountId);

	@POST("api/{namespace}/author/{accountId}")
	Call<ResponseBody> createLink(@Path("namespace") String namespace, @Path("accountId") String accountId);*/
}
