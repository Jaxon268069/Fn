package com.tb24.fn.network;

import com.google.gson.JsonObject;
import com.tb24.fn.model.account.*;
import retrofit2.Call;
import retrofit2.http.*;

import java.util.List;
import java.util.Map;

public interface AccountService {
	String BASE_URL_PROD = "https://account-public-service-prod.ol.epicgames.com/account/";
	String BASE_URL_PROD_ALT = "https://account-public-service-prod.ak.epicgames.com/account/";
	String BASE_URL_STAGE = "https://account-public-service-stage.ol.epicgames.com/account/";

	@GET("api/oauth/verify")
	Call<VerifyResponse> verify(@Query("includePerms") Boolean includePerms);

	/**
	 * <pre>
	 * grant_type           fields
	 * ------------------------------------------------------------
	 * authorization_code   code
	 * client_credentials   -
	 * device_auth          account_id, device_id, secret
	 * device_code          device_code
	 * exchange_code        exchange_code
	 * external_auth        external_auth_type, external_auth_token
	 * otp                  otp, challenge
	 * password             username, password
	 * refresh_token        refresh_token
	 * token_to_token       access_token
	 * </pre>
	 */
	@POST("api/oauth/token")
	@FormUrlEncoded
	Call<Token> getAccessToken(@Header("Authorization") String auth, @Field("grant_type") String grantType, @FieldMap Map<String, String> fields, @Field("includePerms") Boolean includePerms);

	@GET("api/oauth/exchange")
	Call<ExchangeResponse> getExchangeCode();

	/**
	 * @param killType OTHERS, ALL_ACCOUNT_CLIENT, OTHERS_ACCOUNT_CLIENT, OTHERS_ACCOUNT_CLIENT_SERVICE
	 */
	@DELETE("api/oauth/sessions/kill")
	Call<Void> killSessions(@Query("killType") String killType);

	@DELETE("api/oauth/sessions/kill/{accessToken}")
	Call<Void> killSession(@Path("accessToken") String accessToken);

	@POST("api/oauth/deviceAuthorization")
	@FormUrlEncoded
	Call<PinGrantInfo> initiatePinAuth(@Field("prompt") String prompt);

	@DELETE("api/oauth/deviceAuthorization/{userCode}")
	Call<Void> cancelPinAuth(@Path("userCode") String userCode);

	@POST("api/public/account")
	Call<AccountMutationResponse> createAccount(@Query("authenticate") Boolean authenticate, @Query("tokenType") String tokenType, @Query("sendEmail") Boolean sendEmail, @Body AccountMutationPayload payload);

	@GET("api/public/account")
	Call<GameProfile[]> findAccountsByIds(@Query("accountId") List<String> accountIds);

	@GET("api/public/account/{accountId}")
	Call<XGameProfile> getById(@Path("accountId") String accountId);

	@PUT("api/public/account/{accountId}")
	Call<AccountMutationResponse> editAccountDetails(@Path("accountId") String accountId, @Body AccountMutationPayload payload);

	@GET("api/accounts/{accountId}/metadata")
	Call<JsonObject> getAccountMetadata(@Path("accountId") String accountId);

	@GET("api/public/account/{accountId}/deviceAuth")
	Call<DeviceAuth[]> getDeviceAuths(@Path("accountId") String accountId);

	@GET("api/public/account/{accountId}/deviceAuth/{deviceId}")
	Call<DeviceAuth> getDeviceAuth(@Path("accountId") String accountId, @Path("deviceId") String deviceId);

	@POST("api/public/account/{accountId}/deviceAuth")
	Call<DeviceAuth> createDeviceAuth(@Path("accountId") String accountId, @Header("X-Epic-Device-Info") String deviceInfo);

	@DELETE("api/public/account/{accountId}/deviceAuth/{deviceId}")
	Call<Void> deleteDeviceAuth(@Path("accountId") String accountId, @Path("deviceId") String deviceId);

	@GET("api/public/account/{accountId}/externalAuths")
	Call<ExternalAuth[]> getExternalAuths(@Path("accountId") String accountId);

	@GET("api/public/account/{accountId}/externalAuths/{type}")
	Call<ExternalAuth> getExternalAuth(@Path("accountId") String accountId, @Path("type") String type);

	@POST("api/public/account/{accountId}/externalAuths")
	Call<ExternalAuth> createExternalAuth(@Path("accountId") String accountId, @Body AddExternalAuthPayload payload);

	@DELETE("api/public/account/{accountId}/externalAuths/{type}")
	Call<Void> removeExternalAuth(@Path("accountId") String accountId, @Path("type") String type);

	@GET("api/public/account/displayName/{displayName}")
	Call<GameProfile> getByDisplayName(@Path("displayName") String displayName);

	@GET("api/public/account/email/{email}")
	Call<GameProfile> getByEmail(@Path("email") String email);

	@POST("api/public/account/lookup/externalId")
	Call<Map<String, ExternalAuth>> getExternalIdMappingsById(@Body QueryExternalIdMappingsByIdPayload payload);

	@GET("api/public/account/lookup/externalAuth/{externalAuthType}/displayName/{displayName}")
	Call<GameProfile[]> getExternalIdMappingsByDisplayName(@Path("externalAuthType") EExternalAuthType externalAuthType, @Path("displayName") String displayName, @Query("caseInsensitive") Boolean caseInsensitive);

	@GET("api/epicdomains/ssodomains")
	Call<String[]> querySSODomains();
}
