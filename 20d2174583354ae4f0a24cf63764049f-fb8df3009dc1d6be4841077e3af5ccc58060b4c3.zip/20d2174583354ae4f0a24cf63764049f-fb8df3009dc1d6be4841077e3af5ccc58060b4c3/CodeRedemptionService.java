package com.tb24.fn.network;

import com.tb24.fn.model.coderedemption.EvaluateCodeResponse;
import com.tb24.fn.model.coderedemption.LockCodeResponse;
import retrofit2.Call;
import retrofit2.http.POST;
import retrofit2.http.Path;

public interface CodeRedemptionService {
	String BASE_URL_PROD = "https://coderedemption-public-service-prod.ol.epicgames.com/coderedemption/";
	String BASE_URL_STAGE = "https://coderedemption-public-service-stage.ol.epicgames.com/coderedemption/";

	@POST("api/shared/code/{codeId}/lock")
	Call<LockCodeResponse> lockCode(@Path("codeId") String codeId);

	@POST("api/shared/accounts/{accountId}/redeem/{codeId}/evaluate")
	Call<EvaluateCodeResponse> evaluateCode(@Path("accountId") String accountId, @Path("codeId") String codeId);
}
