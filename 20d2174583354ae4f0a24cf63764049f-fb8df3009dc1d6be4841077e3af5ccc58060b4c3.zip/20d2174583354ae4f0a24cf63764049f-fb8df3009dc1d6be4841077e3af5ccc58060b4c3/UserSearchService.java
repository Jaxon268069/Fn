package com.tb24.fn.network;

import com.tb24.fn.model.UserSearchResultEntry;
import com.tb24.fn.model.account.EExternalAuthType;
import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Query;

public interface UserSearchService {
	String BASE_URL_PROD = "https://user-search-service-prod.ol.epicgames.com/";
	String BASE_URL_STAGE = "https://user-search-service-stage.ol.epicgames.com/";

	@GET("api/v1/search")
	Call<UserSearchResultEntry[]> queryUsers(@Query("prefix") String prefix, @Query("platform") EExternalAuthType platform);
}
