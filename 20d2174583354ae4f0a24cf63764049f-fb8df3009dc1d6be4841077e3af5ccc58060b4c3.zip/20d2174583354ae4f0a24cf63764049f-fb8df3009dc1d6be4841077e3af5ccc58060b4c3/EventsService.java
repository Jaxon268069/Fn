package com.tb24.fn.network;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.tb24.fn.model.events.AccountCompetitiveData;
import com.tb24.fn.model.events.EventDownloadResponse;
import com.tb24.fn.model.events.LeaderboardsResponse;
import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Path;
import retrofit2.http.Query;

public interface EventsService {
	/** default */
	String BASE_URL_LIVE = "https://events-public-service-live.ol.epicgames.com/";
	String BASE_URL_LIVE_ALT = "https://events-public-service-live.ak.epicgames.com/";
	String BASE_URL_LOAD_TEST = "https://events-public-service-loadtest.ol.epicgames.com/";
	String BASE_URL_PROD = "https://events-public-service-prod.ol.epicgames.com/";
	String BASE_URL_STAGE = "https://events-public-service-stage.ol.epicgames.com/";

	/**
	 * @param gameId         "Fortnite"
	 * @param accountId      "00112233445566778899aabbccddeeff"
	 * @param regionId       "ASIA"
	 * @param platformName   "Windows"
	 * @param teamAccountIds "00112233445566778899aabbccddeeff"
	 */
	@GET("api/v1/events/{GameId}/download/{AccountId}")
	Call<EventDownloadResponse> download(@Path("GameId") String gameId, @Path("AccountId") String accountId, @Query("region") String regionId, @Query("platform") String platformName, @Query("teamAccountIds") String teamAccountIds);

	/**
	 * TODO haven't tried
	 *
	 * @param gameId          "Fortnite"
	 * @param accountId       "00112233445566778899aabbccddeeff"
	 * @param regionId        "ASIA"
	 * @param bShowPastEvents ???
	 * @param bShowPrivateEvents ???
	 */
	@GET("api/v1/events/{GameId}/data/{AccountId}")
	Call<JsonElement> data(@Path("GameId") String gameId, @Path("AccountId") String accountId, @Query("region") String regionId, @Query("showPastEvents") Boolean bShowPastEvents, @Query("showPrivateEvents") Boolean bShowPrivateEvents);

	/**
	 * TODO haven't tried
	 *
	 * @param gameId        "Fortnite"
	 * @param eventId       "epicgames_OnlineOpen_Week2_ASIA"
	 * @param eventWindowId "OnlineOpen_Week2_ASIA_Event2"
	 */
	@GET("api/v1/events/{GameId}/{EventId}/{EventWindowId}/history")
	Call<JsonElement> history(@Path("GameId") String gameId, @Path("EventId") String eventId, @Path("EventWindowId") String eventWindowId);

	/**
	 * @param gameId            "Fortnite"
	 * @param eventId           "epicgames_OnlineOpen_Week2_ASIA"
	 * @param eventWindowId     "OnlineOpen_Week2_ASIA_Event2"
	 * @param accountId         "00112233445566778899aabbccddeeff"
	 * @param page              0
	 * @param rank              0
	 * @param teamAccountIds    ""
	 * @param appId             "Fortnite"
	 * @param bShowLiveSessions "false"
	 */
	@GET("api/v1/leaderboards/{GameId}/{EventId}/{EventWindowId}/{AccountId}")
	Call<LeaderboardsResponse> leaderboards(@Path("GameId") String gameId, @Path("EventId") String eventId, @Path("EventWindowId") String eventWindowId, @Path("AccountId") String accountId, @Query("page") Integer page, @Query("rank") Integer rank, @Query("teamAccountIds") String teamAccountIds, @Query("appId") String appId, @Query("showLiveSessions") Boolean bShowLiveSessions);

	/**
	 * @param gameId    "Fortnite"
	 * @param accountId "00112233445566778899aabbccddeeff"
	 */
	@GET("api/v1/players/{GameId}/{AccountId}")
	Call<AccountCompetitiveData> eventDataForAccount(@Path("GameId") String gameId, @Path("AccountId") String accountId);

	/**
	 * TODO return object
	 *
	 * @param gameId    "Fortnite"
	 * @param eventId   "epicgames_OnlineOpen_Week2_ASIA"
	 * @param accountId "00112233445566778899aabbccddeeff"
	 */
	@GET("api/v1/events/{GameId}/{EventId}/history/{AccountId}")
	Call<JsonElement[]> eventHistoryForAccount(@Path("GameId") String gameId, @Path("EventId") String eventId, @Path("AccountId") String accountId);

	/**
	 * TODO haven't tried
	 *
	 * @param gameId        "Fortnite"
	 * @param eventId       "epicgames_OnlineOpen_Week2_ASIA"
	 * @param eventWindowId "OnlineOpen_Week2_ASIA_Event2"
	 * @param accountId     "00112233445566778899aabbccddeeff"
	 */
	@GET("api/v1/events/{GameId}/{EventId}/{EventWindowId}/history/{AccountId}")
	Call<JsonElement[]> eventWindowHistoryForAccount(@Path("GameId") String gameId, @Path("EventId") String eventId, @Path("EventWindowId") String eventWindowId, @Path("AccountId") String accountId);

	@GET("api/v1/players/{GameId}/tokens")
	Call<JsonObject> tokens(@Path("GameId") String gameId, @Query("teamAccountIds") String accountIds);
}
