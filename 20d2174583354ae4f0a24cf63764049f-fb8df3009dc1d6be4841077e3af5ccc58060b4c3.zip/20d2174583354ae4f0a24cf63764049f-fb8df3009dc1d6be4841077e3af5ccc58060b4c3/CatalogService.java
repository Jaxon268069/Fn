package com.tb24.fn.network;

import com.tb24.fn.model.Paged;
import com.tb24.fn.model.catalog.Currency;
import com.tb24.fn.model.catalog.StoreItem;
import com.tb24.fn.model.catalog.StoreOffer;
import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Path;
import retrofit2.http.Query;

import java.util.List;
import java.util.Map;

public interface CatalogService {
	String BASE_URL_PROD = "https://catalog-public-service-prod06.ol.epicgames.com/catalog/";
	String BASE_URL_PROD_ALT = "https://catalog-public-service-prod06.ak.epicgames.com/catalog/";
	String BASE_URL_STAGE = "https://catalogv2-public-service-stage.ol.epicgames.com/catalog/";

	@GET("api/shared/currencies")
	Call<Paged<Currency>> queryCurrencies(@Query("start") Integer start, @Query("count") Integer count);

	@GET("api/shared/namespace/{namespace}/items")
	Call<Paged<StoreItem>> queryItems(@Path("namespace") String namespace, @Query("includeDLCDetails") Boolean includeDLCDetails, @Query("includeMainGameDetails") Boolean includeMainGameDetails, @Query("status") String status, @Query("sortBy") String sortBy, @Query("country") String country, @Query("locale") String locale, @Query("start") Integer start, @Query("count") Integer count);

	@GET("api/shared/namespace/{namespace}/offers")
	Call<Paged<StoreOffer>> queryOffers(@Path("namespace") String namespace, @Query("status") String status, /* Maybe */ @Query("country") String country, @Query("locale") String locale, @Query("start") Integer start, @Query("count") Integer count, @Query("returnItemDetails") Boolean returnItemDetails);

	@GET("api/shared/bulk/items")
	Call<Map<String, StoreItem>> queryItemsBulk(@Query("id") List<String> ids, @Query("includeDLCDetails") Boolean includeDLCDetails, @Query("includeMainGameDetails") Boolean includeMainGameDetails, @Query("country") String country, @Query("locale") String locale);

	// Used in Fortnite
	@GET("api/shared/bulk/offers")
	Call<Map<String, StoreOffer>> queryOffersBulk(@Query("id") List<String> ids, @Query("returnItemDetails") Boolean returnItemDetails, @Query("country") String country, @Query("locale") String locale);

	@GET("api/shared/namespace/{namespace}/bulk/items")
	Call<Map<String, StoreItem>> queryItemsBulkNamespace(@Path("namespace") String namespace, @Query("id") List<String> ids, @Query("includeDLCDetails") Boolean includeDLCDetails, @Query("includeMainGameDetails") Boolean includeMainGameDetails, @Query("country") String country, @Query("locale") String locale);

	@GET("api/shared/namespace/{namespace}/bulk/offers")
	Call<Map<String, StoreOffer>> queryOffersBulkNamespace(@Path("namespace") String namespace, @Query("id") List<String> ids, @Query("returnItemDetails") Boolean returnItemDetails, @Query("country") String country, @Query("locale") String locale);
}
