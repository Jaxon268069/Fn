package com.tb24.fn.network;

import com.tb24.fn.model.interactions.LastInteractionsResponse;
import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Path;

public interface InteractionsService {
	String BASE_URL_PROD = "https://interactions-service-prod.ol.epicgames.com/";
	String BASE_URL_STAGE = "https://interactions-service-stage.ol.epicgames.com/";

	@GET("api/v1/{namespace}/get")
	Call<LastInteractionsResponse> queryLastInteractions(@Path("namespace") String namespace);
}
