package com.tb24.fn.network;

import com.google.gson.JsonElement;
import com.tb24.fn.model.EpicGraphQLTypes;
import com.tb24.fn.model.UserSetting;

import java.util.List;

import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.DELETE;
import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.GET;
import retrofit2.http.POST;
import retrofit2.http.PUT;
import retrofit2.http.Path;
import retrofit2.http.Query;

public interface ChannelsService {
	String BASE_URL_PROD = "https://channels-public-service-prod.ol.epicgames.com/";
	String BASE_URL_STAGE = "https://channels-public-service-stage.ol.epicgames.com/";

	@GET("api/v1/user/{accountId}?type=all")
	Call<EpicGraphQLTypes.ChannelSummary> QueryChannelList(@Path("accountId") String accountId);

	@POST("api/v1/channel")
	Call<JsonElement> CreateChannel(@Body EpicGraphQLTypes.CreateChannelRequest payload);

	@DELETE("api/v1/channel/{channelId}/members/{accountId}")
	Call<Void> LeaveChannel(@Path("channelId") String channelId, @Path("accountId") String accountId);

	@GET("api/v1/channel/{channelId}")
	Call<EpicGraphQLTypes.Channel> QueryChannelDetails(@Path("channelId") String channelId);

	// returns 204 by any means
	@POST("api/v1/channel/{channelId}")
	Call<JsonElement> UNKNOWN(@Path("channelId") String channelId);

	@GET("api/v1/channel/{channelId}/members")
	Call<JsonElement> AddToChannel(@Path("channelId") String channelId);

	@GET("api/v1/channel/{channelId}/messages")
	Call<EpicGraphQLTypes.MessagesResult> QueryChannelMessages(@Path("channelId") String channelId);

	@POST("api/v1/channel/{channelId}/messages")
	Call<EpicGraphQLTypes.MesssageCreateResult> SendMessageToChannel(@Path("channelId") String channelId, @Body EpicGraphQLTypes.CreateMessageRequest payload);

	@GET("api/v1/channel/{channelId}/messages/{messageId}")
	Call<EpicGraphQLTypes.MessageResult> QuerySingleChannelMessage(@Path("channelId") String channelId, @Path("messageId") String messageId);

	@DELETE("api/v1/channel/{channelId}/messages/{messageId}")
	Call<Void> DeleteMessageFromChannel(@Path("channelId") String channelId, @Path("messageId") String messageId);

	@GET("api/v1/dm/{accountId}/{peerUserId}/messages")
	Call<JsonElement> QueryDirectMessages(@Path("accountId") String accountId, @Path("peerUserId") String peerUserId);

	@POST("api/v1/dm/{accountId}/{peerUserId}/messages")
	Call<JsonElement> SendDirectMessage(@Path("accountId") String accountId, @Path("peerUserId") String peerUserId);

	@GET("api/v1/dm/{accountId}/{peerUserId}/messages/{messageId}")
	Call<JsonElement> QuerySingleDirectMessage(@Path("accountId") String accountId, @Path("peerUserId") String peerUserId, @Path("messageId") String messageId);

	@DELETE("api/v1/dm/{accountId}/{peerUserId}/messages/{messageId}")
	Call<Void> DeleteDirectMessage(@Path("accountId") String accountId, @Path("peerUserId") String peerUserId, @Path("messageId") String messageId);

	@GET("api/v1/user/{accountId}/setting/{settingKey}")
	Call<UserSetting> QueryUserSetting(@Path("accountId") String accountId, @Path("settingKey") String settingKey);

	/**
	 * @param newSetting only {@link UserSetting#value} is required and read by the server.
	 */
	@PUT("api/v1/user/{accountId}/setting/{settingKey}")
	Call<Void> UpdateUserSetting(@Path("accountId") String accountId, @Path("settingKey") String settingKey, @Body UserSetting newSetting);

	@GET("api/v1/user/{accountId}/setting/{settingKey}/available")
	Call<String[]> QueryAvailableUserSettingValues(@Path("accountId") String accountId, @Path("settingKey") String settingKey);

	@GET("api/v1/user/setting/{settingKey}")
	Call<UserSetting[]> QueryMultiUserSingleSetting(@Query("accountId") List<String> accountIds, @Path("settingKey") String settingKey);

	@POST("api/v1/user/setting/{settingKey}")
	@FormUrlEncoded
	Call<UserSetting[]> QueryMultiUserSingleSetting_Field(@Field("accountId") List<String> accountIds, @Path("settingKey") String settingKey);

	@GET("api/v1/user/setting")
	Call<UserSetting[]> QueryMultiUserMultiSetting(@Query("accountId") List<String> accountIds, @Query("settingKey") List<String> settingKeys);

	@POST("api/v1/user/setting")
	@FormUrlEncoded
	Call<UserSetting[]> QueryMultiUserMultiSetting_Field(@Field("accountId") List<String> accountIds, @Field("settingKey") List<String> settingKeys);

	// TODO Unknown method, cannot be tested
	// @POST("api/v1/user/{accountId}/notifyActive")
	// Call<JsonElement> SendNotifyActive(@Path("accountId") String accountId);
}
