package com.tb24.fn.network;

import com.tb24.fn.model.lightswitch.ServiceStatus;
import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Query;

public interface LightswitchService {
	String BASE_URL_PROD = "https://lightswitch-public-service-prod.ol.epicgames.com/lightswitch/";
	String BASE_URL_PROD_ALT = "https://lightswitch-public-service-prod.ak.epicgames.com/lightswitch/";
	String BASE_URL_STAGE = "https://lightswitch-public-service-stage.ol.epicgames.com/lightswitch/";

	@GET("api/service/bulk/status")
	Call<ServiceStatus[]> queryServiceStatus(@Query("serviceId") String... serviceIds);
}
