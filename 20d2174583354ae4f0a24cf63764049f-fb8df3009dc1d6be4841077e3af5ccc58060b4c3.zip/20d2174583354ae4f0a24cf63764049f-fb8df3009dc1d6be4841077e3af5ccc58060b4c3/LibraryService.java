package com.tb24.fn.network;

import com.tb24.fn.model.library.LibraryItems;
import com.tb24.fn.model.library.Playtime;
import com.tb24.fn.model.library.PlaytimeAddList;
import com.tb24.fn.model.library.PlaytimePayload;
import retrofit2.Call;
import retrofit2.http.*;

public interface LibraryService {
	String BASE_URL = "https://library-service.live.use1a.on.epicgames.com/library/";

	@PUT("api/public/playtime/account/{accountId}")
	Call<Void> sendPlaytime(@Path("accountId") String accountId, @Body PlaytimePayload payload);

	@PUT("api/public/playtime/account/{accountId}/bulk")
	Call<Void> sendPlaytimeBulk(@Path("accountId") String accountId, @Body PlaytimeAddList payload);

	@GET("api/public/playtime/account/{accountId}/artifact/{artifactId}")
	Call<Playtime> queryPlaytime(@Path("accountId") String accountId, @Path("artifactId") String artifactId);

	@GET("api/public/playtime/account/{accountId}/all")
	Call<Playtime[]> queryAllPlaytime(@Path("accountId") String accountId);

	//@GET("api/public/items/hwid/{hardwareId}")
	//Call<Void> queryAntiPiracyTokens(@Path("hardwareId") String hardwareId, @Query("platform") String platform);

	@GET("api/public/items")
	Call<LibraryItems> queryItems(@Query("includeMetadata") Boolean includeMetadata, @Query("cursor") String cursor, @Query("excludeNs") String... excludeNs);
}
