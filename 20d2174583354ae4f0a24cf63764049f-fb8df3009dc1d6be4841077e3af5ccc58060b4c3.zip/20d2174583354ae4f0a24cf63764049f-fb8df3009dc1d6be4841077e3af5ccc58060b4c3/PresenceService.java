package com.tb24.fn.network;

import com.tb24.fn.model.presence.LastOnline;
import com.tb24.fn.model.presence.NudgedSubscription;
import com.tb24.fn.model.presence.Subscription;
import com.tb24.fn.model.presence.SubscriptionSettings;
import retrofit2.Call;
import retrofit2.http.*;

import java.util.Map;

public interface PresenceService {
	String BASE_URL_PROD = "https://presence-public-service-prod.ol.epicgames.com/presence/";
	String BASE_URL_STAGE = "https://presence-public-service-stage.ol.epicgames.com/presence/";

	@GET("api/v1/_/{id}/last-online")
	Call<Map<String, LastOnline[]>> queryLastOnline(@Path("id") String id);

	@GET("api/v1/_/{id}/settings/subscriptions")
	Call<SubscriptionSettings> querySubscriptionSettings(@Path("id") String id);

	@PATCH("api/v1/_/{id}/settings/subscriptions")
	Call<Void> updateSubscriptionSettings(@Path("id") String id, @Body SubscriptionSettings payload);

	@POST("api/v1/_/{id}/subscriptions/{otherId}")
	Call<Void> subscribe(@Path("id") String id);

	@DELETE("api/v1/_/{id}/subscriptions/{otherId}")
	Call<Void> unsubscribe(@Path("id") String id);

	@GET("api/v1/_/{id}/subscriptions")
	Call<Subscription[]> querySubscriptions(@Path("id") String id);

	@POST("api/v1/{namespace}/{id}/subscriptions/broadcast")
	Call<Void> broadcastSubscription(@Path("id") String id);

	@PUT("api/v1/{namespace}/{id}/subscriptions/nudged/{otherId}")
	Call<Void> sendSubscriptionNudge(@Path("namespace") String namespace, @Path("id") String id, @Path("otherId") String otherId);

	@GET("api/v1/{namespace}/{id}/subscriptions/nudged")
	Call<NudgedSubscription[]> queryNudgedSubscriptions(@Path("namespace") String namespace, @Path("id") String id);
}
