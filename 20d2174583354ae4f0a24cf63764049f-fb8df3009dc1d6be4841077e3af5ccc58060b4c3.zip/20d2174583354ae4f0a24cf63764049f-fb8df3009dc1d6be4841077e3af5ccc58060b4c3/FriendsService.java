package com.tb24.fn.network;

import com.google.gson.JsonObject;
import com.tb24.fn.model.friends.*;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.http.*;

public interface FriendsService {
	String BASE_URL_PROD = "https://friends-public-service-prod.ol.epicgames.com/friends/";
	String BASE_URL_PROD_ALT = "https://friends-public-service-prod.ak.epicgames.com/friends/";
	String BASE_URL_STAGE = "https://friends-public-service-stage.ol.epicgames.com/friends/";

	@GET("api/v1/{id}/summary")
	Call<FriendsSummary> queryFriendsSummary(@Path("id") String id, @Query("displayNames") Boolean displayNames);

	@GET("api/v1/{id}/friends")
	Call<FriendV2[]> queryFriends(@Path("id") String id, @Query("displayNames") Boolean displayNames);

	@GET("api/v1/{id}/friends/{friend}")
	Call<FriendV2> queryFriend(@Path("id") String id, @Path("friend") String friend, @Query("displayNames") Boolean displayNames);

	@POST("api/v1/{id}/friends/{friend}")
	Call<Void> sendInviteOrAcceptInvite(@Path("id") String id, @Path("friend") String friend);

	@DELETE("api/v1/{id}/friends/{friend}")
	Call<Void> deleteFriendOrRejectInvite(@Path("id") String id, @Path("friend") String friend);

	@PUT("api/v1/{id}/friends/{friend}/alias")
	Call<Void> setFriendAlias(@Path("id") String id, @Path("friend") String friend, @Body RequestBody newAlias);

	@DELETE("api/v1/{id}/friends/{friend}/alias")
	Call<Void> deleteFriendAlias(@Path("id") String id, @Path("friend") String friend);

	@PUT("api/v1/{id}/friends/{friend}/note")
	Call<Void> setFriendNote(@Path("id") String id, @Path("friend") String friend, @Body RequestBody newNote);

	@DELETE("api/v1/{id}/friends/{friend}/note")
	Call<Void> deleteFriendNote(@Path("id") String id, @Path("friend") String friend);

	@GET("api/v1/{id}/incoming")
	Call<FriendV2[]> queryIncomingFriendRequests(@Path("id") String id, @Query("displayNames") Boolean displayNames);

	@GET("api/v1/{id}/outgoing")
	Call<FriendV2[]> queryOutgoingFriendRequests(@Path("id") String id, @Query("displayNames") Boolean displayNames);

	@GET("api/v1/{id}/blocklist")
	Call<FriendV2[]> queryBlockedPlayers(@Path("id") String id, @Query("displayNames") Boolean displayNames);

	@POST("api/v1/{id}/blocklist/{block}")
	Call<Void> sendBlock(@Path("id") String id, @Path("block") String block);

	@DELETE("api/v1/{id}/blocklist/{block}")
	Call<Void> sendUnblock(@Path("id") String id, @Path("block") String block);

	/**
	 * @param namespace ex: "fortnite"
	 */
	@GET("api/v1/{id}/recent/{namespace}")
	Call<Friend[]> queryRecentPlayers(@Path("id") String id, @Path("namespace") String namespace);

	// TODO unknown parameters, 403 for user access token
	@POST("api/v1/recent/{namespace}")
	Call<Void> addBulkRecentPlayers(@Path("namespace") String namespace);

	@GET("api/v1/{id}/settings")
	Call<FriendsSettings> queryFriendSettings(@Path("id") String id);

	@PUT("api/v1/{id}/settings")
	Call<FriendsSettings> setFriendSettings(@Path("id") String id, @Body FriendsSettings newSettings);

	/**
	 * @param source ex: "steam"
	 */
	@GET("api/v1/{id}/settings/externalSources/{source}")
	Call<JsonObject> queryFriendExternalSourceSettings(@Path("id") String id, @Path("source") String source);

	@PUT("api/v1/{id}/settings/externalSources/{source}")
	Call<JsonObject> setFriendExternalSourceSettings(@Path("id") String id, @Path("source") String source, @Body JsonObject newSettings);

	@Deprecated
	@GET("api/public/friends/{id}")
	Call<Friend[]> LEGACY_queryFriends(@Path("id") String id, @Query("includePending") Boolean includePending);

	@Deprecated
	@GET("api/public/blocklist/{id}")
	Call<BlockedUsers> LEGACY_queryBlockedPlayers(@Path("id") String id);
}
