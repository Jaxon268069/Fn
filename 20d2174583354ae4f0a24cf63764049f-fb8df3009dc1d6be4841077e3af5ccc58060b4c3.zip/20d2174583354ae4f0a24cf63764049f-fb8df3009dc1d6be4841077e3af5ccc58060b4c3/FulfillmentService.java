package com.tb24.fn.network;

import com.tb24.fn.model.RedeemCodePayload;
import com.tb24.fn.model.RedeemCodeResponse;
import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.POST;
import retrofit2.http.Path;
import retrofit2.http.Query;

public interface FulfillmentService {
	String BASE_URL_PROD = "https://fulfillment-public-service-prod.ol.epicgames.com/fulfillment/";
	String BASE_URL_STAGE = "https://fulfillment-public-service-stage.ol.epicgames.com/fulfillment/";

	@POST("api/public/accounts/{accountId}/codes/{codeId}")
	Call<RedeemCodeResponse> redeemCode(@Path("accountId") String accountId, @Path("codeId") String codeId, @Query("codeUseId") String codeUseId, @Body RedeemCodePayload payload);
}
